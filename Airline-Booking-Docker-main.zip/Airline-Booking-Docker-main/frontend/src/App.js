import './App.css';
import MyRoutes from './MyRoutes';
function App() {

  return (
    <div className="App">
      <MyRoutes/>
    </div>
  );
}

export default App;
