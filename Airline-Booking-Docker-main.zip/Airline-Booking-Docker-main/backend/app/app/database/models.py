from app.booking.models import Booking
from app.user.models import User
from app.catalog.models import Flight